import React from 'react';
import { SpaceBackground } from '../components/landing/SpaceBackground';
import { AuthPage } from '../components/landing/AuthPage';
import { useNavigate } from 'react-router-dom';

export const LoginPage: React.FC = () => {
  const navigate = useNavigate();
  return (
    <div className="relative min-h-screen overflow-hidden text-white" style={{ backgroundColor: '#04040f' }}>
      <SpaceBackground />
      <AuthPage initialMode="login" onBack={() => navigate('/')} />
    </div>
  );
};