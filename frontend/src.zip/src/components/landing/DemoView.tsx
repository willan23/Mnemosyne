import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { Canvas } from '@react-three/fiber';
import { OrbitControls, Stars, Text } from '@react-three/drei';
import { Brain, X, Sparkles, Move } from 'lucide-react';

/* ─── Mock Data ───────────────────────────────────────────── */
const MOCK_MEMORIES = [
  { id: 1, text: 'Ideia para o design do Cognitive OS', pos: [0, 0, 0] },
  { id: 2, text: 'Conceito de Zero-knowledge architecture', pos: [3, 2, -1] },
  { id: 3, text: 'Estudo sobre grafos cognitivos', pos: [-2, -1, 2] },
  { id: 4, text: 'Reunião com a equipa de segurança', pos: [1, -3, -2] },
  { id: 5, text: 'Apresentação WGF-Security', pos: [-4, 2, -3] },
];

/* ─── Interactive Nodes ───────────────────────────────────── */
const InteractiveNodes: React.FC = () => {
  const [hovered, setHovered] = useState<number | null>(null);

  return (
    <group>
      {MOCK_MEMORIES.map((mem) => (
        <mesh
          key={mem.id}
          position={mem.pos as [number, number, number]}
          onPointerOver={(e) => { e.stopPropagation(); setHovered(mem.id); document.body.style.cursor = 'pointer'; }}
          onPointerOut={(e) => { e.stopPropagation(); setHovered(null); document.body.style.cursor = 'auto'; }}
          onClick={(e) => { e.stopPropagation(); /* Tiny zoom effect could go here */ }}
        >
          <sphereGeometry args={[hovered === mem.id ? 0.3 : 0.15, 32, 32]} />
          <meshBasicMaterial color={hovered === mem.id ? '#22d3ee' : '#8b5cf6'} />
          
          {hovered === mem.id && (
            <Text
              position={[0, 0.6, 0]}
              fontSize={0.3}
              color="white"
              anchorX="center"
              anchorY="middle"
              outlineWidth={0.02}
              outlineColor="#020617"
            >
              {mem.text}
            </Text>
          )}
        </mesh>
      ))}

      {/* Draw lines between nodes */}
      <lineSegments>
        <bufferGeometry>
          <bufferAttribute
            attach="attributes-position"
            args={[
              new Float32Array([
                0,0,0,  3,2,-1,
                0,0,0,  -2,-1,2,
                3,2,-1, -4,2,-3,
                -2,-1,2, 1,-3,-2,
              ]),
              3
            ]}
          />
        </bufferGeometry>
        <lineBasicMaterial color="#8b5cf6" transparent opacity={0.3} />
      </lineSegments>
    </group>
  );
};

/* ─── Demo View Component ─────────────────────────────────── */
interface DemoViewProps {
  onExit: () => void;
  onSignup: () => void;
}

export const DemoView: React.FC<DemoViewProps> = ({ onExit, onSignup }) => {
  return (
    <motion.div
      key="demo-view"
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0 }}
      transition={{ duration: 0.5 }}
      className="fixed inset-0 z-50 bg-[#020617]"
    >
      <Canvas camera={{ position: [0, 0, 8], fov: 60 }}>
        <ambientLight intensity={0.5} />
        <Stars radius={100} depth={50} count={5000} factor={4} saturation={0} fade speed={1} />
        <InteractiveNodes />
        <OrbitControls enablePan={false} maxDistance={15} minDistance={2} />
      </Canvas>

      {/* Top HUD */}
      <div className="absolute top-0 left-0 right-0 p-6 flex items-center justify-between pointer-events-none">
        <div className="flex items-center gap-3">
          <div className="p-2 rounded-xl bg-violet-500/10 border border-violet-500/20 backdrop-blur-md">
            <Brain className="w-5 h-5 text-violet-400" />
          </div>
          <div>
            <h2 className="text-sm font-semibold text-white">Modo Demo</h2>
            <p className="text-xs text-slate-400">Interage com os pontos no universo</p>
          </div>
        </div>

        <button
          onClick={onExit}
          className="pointer-events-auto flex items-center gap-2 px-4 py-2 rounded-full mnem-glass text-sm text-slate-300 hover:text-white transition-colors"
        >
          <X className="w-4 h-4" />
          Sair da demo
        </button>
      </div>

      {/* Bottom HUD */}
      <div className="absolute bottom-8 left-1/2 -translate-x-1/2 flex items-center gap-4 pointer-events-auto">
        <div className="flex items-center gap-2 px-4 py-2 rounded-full mnem-glass text-xs text-slate-300 pointer-events-none">
          <Move className="w-3 h-3 text-cyan-400" />
          Scroll para zoom. Arrastar para rodar.
        </div>
        <button
          onClick={onSignup}
          className="mnem-btn-primary py-2 px-6"
        >
          <Sparkles className="w-4 h-4" />
          Criar o meu universo
        </button>
      </div>
    </motion.div>
  );
};
