import React, { useEffect, useRef } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { X, Brain, Sparkles, Zap, Lock, Play } from 'lucide-react';

/* ─── Feature pills ───────────────────────────────────────── */
const FEATURES = [
  { icon: Zap,      label: 'Memórias vivas',      color: '#818cf8', bg: 'rgba(129,140,248,0.12)' },
  { icon: Brain,    label: 'IA cognitiva',         color: '#a78bfa', bg: 'rgba(167,139,250,0.12)' },
  { icon: Lock,     label: 'Zero-knowledge',       color: '#60a5fa', bg: 'rgba(96,165,250,0.12)'  },
  { icon: Sparkles, label: 'Ligações automáticas', color: '#34d399', bg: 'rgba(52,211,153,0.12)'  },
];

/* ─── Pure CSS star field (no R3F conflict) ───────────────── */
interface Star { x: number; y: number; r: number; delay: number; color: string; }

const StarCanvas: React.FC = () => {
  const canvasRef = useRef<HTMLCanvasElement>(null);

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    const W = canvas.width  = canvas.offsetWidth;
    const H = canvas.height = canvas.offsetHeight;

    const palette = ['#818cf8', '#a78bfa', '#60a5fa', '#c4d4ff', '#f0f4ff'];
    const stars: Star[] = Array.from({ length: 60 }, () => ({
      x:     Math.random() * W,
      y:     Math.random() * H,
      r:     Math.random() * 2.5 + 0.3,
      delay: Math.random() * Math.PI * 2,
      color: palette[Math.floor(Math.random() * palette.length)],
    }));

    // Node positions for connections
    const nodes = Array.from({ length: 14 }, () => ({
      x: Math.random() * W,
      y: Math.random() * H,
    }));

    let frame = 0;
    let raf: number;

    function draw() {
      if (!ctx || !canvas) return;
      ctx.clearRect(0, 0, W, H);

      // Connections
      for (let i = 0; i < nodes.length; i++) {
        for (let j = i + 1; j < nodes.length; j++) {
          const dx = nodes[i].x - nodes[j].x;
          const dy = nodes[i].y - nodes[j].y;
          const dist = Math.sqrt(dx * dx + dy * dy);
          if (dist < 120) {
            ctx.beginPath();
            ctx.strokeStyle = `rgba(99,102,241,${0.15 * (1 - dist / 120)})`;
            ctx.lineWidth = 0.7;
            ctx.moveTo(nodes[i].x, nodes[i].y);
            ctx.lineTo(nodes[j].x, nodes[j].y);
            ctx.stroke();
          }
        }
      }

      // Stars with twinkle
      for (const s of stars) {
        const alpha = 0.5 + 0.5 * Math.sin(frame * 0.02 + s.delay);
        ctx.beginPath();
        ctx.arc(s.x, s.y, s.r, 0, Math.PI * 2);
        ctx.fillStyle = s.color + Math.round(alpha * 255).toString(16).padStart(2, '0');
        ctx.fill();
      }

      // Nebula glow
      const cx = W * 0.5 + Math.sin(frame * 0.005) * W * 0.08;
      const cy = H * 0.45 + Math.cos(frame * 0.007) * H * 0.06;
      const grad = ctx.createRadialGradient(cx, cy, 0, cx, cy, 90);
      grad.addColorStop(0, 'rgba(99,102,241,0.14)');
      grad.addColorStop(1, 'rgba(99,102,241,0)');
      ctx.fillStyle = grad;
      ctx.fillRect(0, 0, W, H);

      frame++;
      raf = requestAnimationFrame(draw);
    }

    draw();
    return () => cancelAnimationFrame(raf);
  }, []);

  return (
    <canvas
      ref={canvasRef}
      className="absolute inset-0 w-full h-full"
      style={{ display: 'block' }}
    />
  );
};

/* ─── Modal ───────────────────────────────────────────────── */
interface DemoModalProps {
  isOpen:       boolean;
  onClose:      () => void;
  onStartFree:  () => void;
}

export const DemoModal: React.FC<DemoModalProps> = ({ isOpen, onClose, onStartFree }) => (
  <AnimatePresence>
    {isOpen && (
      <>
        {/* Backdrop */}
        <motion.div
          key="demo-backdrop"
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          transition={{ duration: 0.25 }}
          className="fixed inset-0 z-50 bg-black/75 backdrop-blur-sm"
          onClick={onClose}
        />

        {/* Modal */}
        <motion.div
          key="demo-modal"
          initial={{ opacity: 0, scale: 0.88, y: 24 }}
          animate={{ opacity: 1, scale: 1,    y: 0  }}
          exit={{ opacity: 0,   scale: 0.92,  y: 12 }}
          transition={{ duration: 0.38, ease: [0.22, 1, 0.36, 1] }}
          className="fixed inset-0 z-50 flex items-center justify-center p-4 pointer-events-none"
        >
          <div
            className="relative w-full max-w-2xl pointer-events-auto overflow-hidden rounded-3xl"
            style={{
              background: 'rgba(5,5,20,0.94)',
              border: '1px solid rgba(255,255,255,0.09)',
              boxShadow: '0 48px 120px rgba(0,0,0,0.85), 0 0 0 1px rgba(99,102,241,0.1)',
            }}
          >
            {/* Close */}
            <button
              onClick={onClose}
              className="absolute top-5 right-5 z-10 p-2 rounded-full transition-all"
              style={{ color: 'rgba(240,240,255,0.35)' }}
              onMouseEnter={e => {
                (e.currentTarget as HTMLElement).style.background = 'rgba(255,255,255,0.08)';
                (e.currentTarget as HTMLElement).style.color = 'rgba(240,240,255,0.9)';
              }}
              onMouseLeave={e => {
                (e.currentTarget as HTMLElement).style.background = 'transparent';
                (e.currentTarget as HTMLElement).style.color = 'rgba(240,240,255,0.35)';
              }}
            >
              <X className="w-5 h-5" />
            </button>

            {/* Preview area — pure canvas, no R3F */}
            <div
              className="relative w-full overflow-hidden"
              style={{
                height: '260px',
                background: 'radial-gradient(ellipse at 50% 60%, rgba(99,102,241,0.13) 0%, #03030d 72%)',
              }}
            >
              <StarCanvas />

              {/* Vignette */}
              <div className="absolute inset-0 bg-gradient-to-t from-[#05051a] via-transparent to-[#05051a]/60 pointer-events-none" />

              {/* HUD label */}
              <motion.div
                initial={{ opacity: 0, x: -10 }}
                animate={{ opacity: 1, x: 0 }}
                transition={{ delay: 0.35 }}
                className="absolute left-5 top-5 flex items-center gap-2"
              >
                <div className="p-1.5 rounded-lg bg-indigo-500/10 border border-indigo-500/20">
                  <Brain className="w-4 h-4 text-indigo-400" />
                </div>
                <span className="text-xs font-semibold" style={{ color: 'rgba(240,240,255,0.8)' }}>
                  Mnemosyne Universe
                </span>
              </motion.div>

              {/* Floating status pills */}
              {([ 'Ligação descoberta', 'Memória criada', 'Padrão detectado'] as const).map((label, i) => (
                <motion.div
                  key={label}
                  initial={{ opacity: 0, scale: 0.8 }}
                  animate={{
                    opacity: [0, 1, 1, 0],
                    scale:   [0.8, 1, 1, 0.85],
                    y:       [4, 0, 0, -4],
                  }}
                  transition={{
                    delay:       0.6 + i * 1.2,
                    duration:    2.0,
                    repeat:      Infinity,
                    repeatDelay: 2,
                  }}
                  className="absolute px-3 py-1.5 rounded-full text-[11px] font-medium"
                  style={{
                    bottom:     `${55 + i * 42}px`,
                    right:      `${28 + i * 24}px`,
                    background: 'rgba(99,102,241,0.18)',
                    border:     '1px solid rgba(99,102,241,0.32)',
                    color:      '#a5b4fc',
                    backdropFilter: 'blur(8px)',
                  }}
                >
                  {label}
                </motion.div>
              ))}

              {/* Play hint */}
              <div
                className="absolute bottom-5 left-1/2 -translate-x-1/2 flex items-center gap-2 px-4 py-2 rounded-full"
                style={{
                  background: 'rgba(0,0,0,0.45)',
                  border: '1px solid rgba(255,255,255,0.08)',
                  backdropFilter: 'blur(12px)',
                }}
              >
                <Play className="w-3 h-3 text-indigo-400" />
                <span className="text-[11px]" style={{ color: 'rgba(240,240,255,0.55)' }}>
                  Universo cognitivo vivo
                </span>
              </div>
            </div>

            {/* Content */}
            <div className="px-8 pb-8 pt-6">
              <h2 className="text-2xl font-bold text-white mb-2">
                O teu universo{' '}
                <span className="mnem-gradient-text">cognitivo vivo</span>
              </h2>
              <p className="text-sm mb-6 leading-relaxed" style={{ color: 'var(--text-secondary)' }}>
                Cada pensamento torna-se uma estrela. A IA descobre ligações
                automaticamente. A tua privacidade é absoluta — os dados nunca
                saem do teu dispositivo.
              </p>

              {/* Feature grid */}
              <div className="grid grid-cols-2 gap-3 mb-7">
                {FEATURES.map(({ icon: Icon, label, color, bg }) => (
                  <div
                    key={label}
                    className="flex items-center gap-3 px-4 py-3 rounded-2xl"
                    style={{ background: bg, border: '1px solid rgba(255,255,255,0.06)' }}
                  >
                    <Icon className="w-4 h-4 flex-shrink-0" style={{ color }} />
                    <span className="text-sm font-medium" style={{ color: 'rgba(240,240,255,0.8)' }}>
                      {label}
                    </span>
                  </div>
                ))}
              </div>

              {/* CTAs */}
              <div className="flex items-center gap-3">
                <button
                  onClick={() => { onClose(); onStartFree(); }}
                  className="mnem-btn-primary flex-1 justify-center"
                >
                  <Sparkles className="w-4 h-4" />
                  Começar grátis
                </button>
                <button
                  onClick={onClose}
                  className="mnem-btn-ghost px-5 py-3 text-sm"
                >
                  Fechar
                </button>
              </div>
            </div>
          </div>
        </motion.div>
      </>
    )}
  </AnimatePresence>
);
