import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Brain, Search, Plus, Sparkles } from 'lucide-react';

/* ─── Feedback states ─────────────────────────────────────── */
const FEEDBACK_MESSAGES = [
  "A interpretar o teu pensamento...",
  "A ligar ideias antigas...",
  "A encontrar padrões...",
];

export const AuthenticatedView: React.FC<{ onLogout: () => void }> = ({ onLogout }) => {
  const [isFlowMode, setIsFlowMode] = useState(false);
  const [text, setText] = useState('');
  const [isProcessing, setIsProcessing] = useState(false);
  const [feedbackIndex, setFeedbackIndex] = useState(0);

  // Rotate feedback messages
  useEffect(() => {
    if (!isProcessing) return;
    
    let i = 0;
    const interval = setInterval(() => {
      i = (i + 1) % FEEDBACK_MESSAGES.length;
      setFeedbackIndex(i);
    }, 1500);

    // Mock processing finishing
    const timer = setTimeout(() => {
      setIsProcessing(false);
      setText('');
      setIsFlowMode(false);
      setFeedbackIndex(0);
    }, 4500);

    return () => {
      clearInterval(interval);
      clearTimeout(timer);
    };
  }, [isProcessing]);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!text.trim()) return;
    setIsProcessing(true);
  };

  return (
    <motion.div
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0 }}
      transition={{ duration: 0.8 }}
      className="absolute inset-0 z-50 pointer-events-none flex flex-col items-center justify-center p-6"
    >
      {/* Background zoom effect triggered by FlowMode */}
      <motion.div
        animate={{ scale: isFlowMode ? 1.05 : 1 }}
        transition={{ duration: 1.5, ease: 'easeInOut' }}
        className="fixed inset-0 pointer-events-none"
        style={{ zIndex: -1 }}
      />

      {/* Top Bar - Hidden when in focus */}
      <AnimatePresence>
        {!isFlowMode && !isProcessing && (
          <motion.header
            initial={{ opacity: 0, y: -20 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -20 }}
            className="absolute top-0 left-0 right-0 p-6 flex justify-between pointer-events-auto"
          >
            <div className="flex items-center gap-3">
              <div className="p-1.5 rounded-lg bg-violet-500/10 border border-violet-500/20">
                <Brain className="w-5 h-5 text-violet-400" />
              </div>
            </div>
            <button
              onClick={onLogout}
              className="text-xs text-slate-400 hover:text-white transition-colors"
            >
              Sair (Mock)
            </button>
          </motion.header>
        )}
      </AnimatePresence>

      {/* Central Input - Flow Mode */}
      <div className="w-full max-w-2xl pointer-events-auto relative">
        <AnimatePresence mode="wait">
          {isProcessing ? (
            <motion.div
              key="processing"
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -10 }}
              className="flex flex-col items-center justify-center py-10"
            >
              <div className="relative mb-6">
                <Brain className="w-10 h-10 text-violet-400 opacity-80" />
                <motion.div
                  className="absolute inset-0 rounded-full border-2 border-transparent"
                  style={{ borderTopColor: '#8b5cf6', borderBottomColor: '#22d3ee' }}
                  animate={{ rotate: 360 }}
                  transition={{ duration: 2, repeat: Infinity, ease: 'linear' }}
                />
              </div>
              <motion.p
                key={feedbackIndex}
                initial={{ opacity: 0, y: 5 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: -5 }}
                className="text-lg font-medium bg-gradient-to-r from-violet-300 to-cyan-300 bg-clip-text text-transparent"
              >
                {FEEDBACK_MESSAGES[feedbackIndex]}
              </motion.p>
            </motion.div>
          ) : (
            <motion.form
              key="input"
              initial={{ opacity: 0, scale: 0.95 }}
              animate={{ opacity: 1, scale: 1 }}
              onSubmit={handleSubmit}
              className={`relative transition-all duration-700 ease-out ${
                isFlowMode ? 'scale-110 shadow-[0_0_80px_rgba(139,92,246,0.15)]' : ''
              }`}
            >
              <div
                className={`absolute inset-0 rounded-3xl transition-opacity duration-700 pointer-events-none ${
                  isFlowMode ? 'opacity-100' : 'opacity-0'
                }`}
                style={{
                  background: 'linear-gradient(135deg, rgba(139,92,246,0.2) 0%, rgba(34,211,238,0.2) 100%)',
                  filter: 'blur(40px)',
                  zIndex: -1
                }}
              />
              <div
                className="relative flex items-center p-2 rounded-3xl mnem-glass transition-all duration-500"
                style={{
                  background: isFlowMode ? 'rgba(5, 10, 30, 0.85)' : 'rgba(255, 255, 255, 0.03)',
                  borderColor: isFlowMode ? 'rgba(139,92,246,0.4)' : 'rgba(255,255,255,0.08)'
                }}
              >
                <div className="pl-4 pr-3 text-slate-400">
                  {isFlowMode ? <Sparkles className="w-5 h-5 text-violet-400" /> : <Search className="w-5 h-5" />}
                </div>
                <input
                  type="text"
                  value={text}
                  onChange={(e) => setText(e.target.value)}
                  onFocus={() => setIsFlowMode(true)}
                  onBlur={() => !text && setIsFlowMode(false)}
                  placeholder="O que estás a pensar agora?"
                  className="w-full bg-transparent border-none outline-none text-white placeholder-slate-500 text-lg py-4"
                  autoComplete="off"
                />
                <AnimatePresence>
                  {text && (
                    <motion.button
                      initial={{ opacity: 0, scale: 0.8 }}
                      animate={{ opacity: 1, scale: 1 }}
                      exit={{ opacity: 0, scale: 0.8 }}
                      type="submit"
                      className="p-3 mr-1 bg-violet-600 hover:bg-violet-500 text-white rounded-2xl transition-colors"
                    >
                      <Plus className="w-5 h-5" />
                    </motion.button>
                  )}
                </AnimatePresence>
              </div>
            </motion.form>
          )}
        </AnimatePresence>
      </div>

      {/* Instructional Hint */}
      {!isFlowMode && !isProcessing && (
        <motion.p
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 1 }}
          className="absolute bottom-10 text-xs text-slate-500 tracking-widest uppercase font-semibold"
        >
          O Universo aguarda os teus pensamentos
        </motion.p>
      )}
    </motion.div>
  );
};
