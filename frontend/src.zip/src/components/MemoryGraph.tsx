import React, { useRef, useMemo, useState, useEffect, useCallback } from 'react';
import ForceGraph2D from 'react-force-graph-2d';

interface Node {
    id: string;
    name: string;
    val: number;
    // D3 properties added lazily
    x?: number;
    y?: number;
}

interface Link {
    source: string | Node;
    target: string | Node;
}

interface GraphData {
    nodes: Node[];
    links: Link[];
}

export const MemoryGraph: React.FC<{ data?: GraphData }> = ({ data }) => {
    const fgRef = useRef<any>(null);
    const [highlightNodes, setHighlightNodes] = useState(new Set());
    const [highlightLinks, setHighlightLinks] = useState(new Set());
    const [dimensions, setDimensions] = useState({ width: 800, height: 600 });
    const containerRef = useRef<HTMLDivElement>(null);

    // Monitor resize
    useEffect(() => {
        const updateDimensions = () => {
            if (containerRef.current) {
                setDimensions({
                    width: containerRef.current.clientWidth,
                    height: containerRef.current.clientHeight
                });
            }
        };

        window.addEventListener('resize', updateDimensions);
        updateDimensions();

        // Pequeno delay para garantir que o container montou
        setTimeout(updateDimensions, 100);

        return () => window.removeEventListener('resize', updateDimensions);
    }, []);

    // Use mock data if none provided
    const rawData = data || {
        nodes: [
            { id: '1', name: 'Mnemosyne', val: 10 },
            { id: '2', name: 'Início', val: 5 },
            { id: '3', name: 'Design', val: 7 },
            { id: '4', name: 'E2EE', val: 8 },
            { id: '5', name: 'Vite', val: 4 },
        ],
        links: [
            { source: '1', target: '2' },
            { source: '1', target: '3' },
            { source: '1', target: '4' },
            { source: '3', target: '5' },
        ]
    };

    // Process data: Clone and limit nodes for performance
    // Process data: Clone and limit nodes for performance
    const processedGraphData = useMemo(() => {
        // CRITICAL: Deep clone to prevent mutation issues with react-force-graph/d3
        let cleanData;
        try {
            cleanData = JSON.parse(JSON.stringify(rawData));
        } catch (e) {
            console.error("Grave: Erro ao clonar dados do grafo", e);
            return { nodes: [], links: [] };
        }

        const maxNodes = 5000; // Expanded to 5000: WebGL/Canvas2D can handle it easily with simplified rendering

        // Helper to extract ID safe
        const getId = (n: any) => (typeof n === 'object' && n !== null ? n.id : n);

        let nodes = cleanData.nodes;
        const links = cleanData.links;

        // Limite superior de segurança para navegadores muito fracos
        if (nodes.length > maxNodes) {
            nodes = nodes.slice(0, maxNodes);
        }

        // Create a fast lookup Set of valid Node IDs
        const nodeIds = new Set(nodes.map((n: any) => getId(n)));

        // Filter and Normalize Links
        // MUST ensure source/target are strings (IDs) matching the nodes list
        const safeLinks = links.reduce((acc: any[], link: any) => {
            const sourceId = getId(link.source);
            const targetId = getId(link.target);

            // Only keep link if BOTH ends exist in our filtered node list
            if (nodeIds.has(sourceId) && nodeIds.has(targetId)) {
                // Return a clean link object with String IDs
                acc.push({
                    source: sourceId,
                    target: targetId,
                    value: link.value
                });
            }
            return acc;
        }, []);

        return { nodes, links: safeLinks };
    }, [rawData]);

    // Vibrant color palette for nodes
    const nodeColors = [
        '#FF6B6B', // Coral Red
        '#4ECDC4', // Turquoise
        '#FFE66D', // Sunny Yellow
        '#A8E6CF', // Mint Green
        '#FF8B94', // Pink
        '#C7CEEA', // Lavender
        '#FFDAC1', // Peach
        '#B4F8C8', // Light Green
        '#FBE7C6', // Cream
        '#A0E7E5', // Aqua
    ];

    // Configure Graph Layout Forces
    useEffect(() => {
        if (fgRef.current) {
            // Increase repulsion (Negative charge) to separate nodes
            fgRef.current.d3Force('charge').strength(-400); // Was -100

            // Increase distance between connected nodes
            fgRef.current.d3Force('link').distance(120); // Was 50

            // Add collision detection to prevent overlap
            // Radius 25 ensures safe buffer around nodes (radius ~8-10)
            const collide = fgRef.current.d3Force('collide');
            if (collide) {
                collide.radius(35).strength(0.8);
            } else {
                // Se a força de colisão não existir por padrão, podemos tentar injetar (mas geralmente existe)
                // A lib react-force-graph-2d geralmente já traz configurado. 
                // Se não pegar, o 'charge' alto já ajuda muito.
            }

            // Adjust centering force (optional, prevents "exploding" too far)
            fgRef.current.d3Force('center').strength(0.05);

            // Reheat simulation
            fgRef.current.d3ReheatSimulation();
        }
    }, [processedGraphData]);

    const handleNodeHover = useCallback((node: any) => {
        const nodes = new Set();
        const links = new Set();

        if (node) {
            nodes.add(node.id);
            processedGraphData.links.forEach((link: any) => {
                // Handle both object references (d3) and string IDs (raw)
                const sourceId = typeof link.source === 'object' ? link.source.id : link.source;
                const targetId = typeof link.target === 'object' ? link.target.id : link.target;

                if (sourceId === node.id || targetId === node.id) {
                    links.add(link);
                    nodes.add(sourceId);
                    nodes.add(targetId);
                }
            });
        }

        setHighlightNodes(nodes);
        setHighlightLinks(links);
    }, [processedGraphData]);

    const getColorIndex = (id: string) => {
        let hash = 0;
        for (let i = 0; i < id.length; i++) {
            hash = ((hash << 5) - hash) + id.charCodeAt(i);
            hash = hash & hash;
        }
        return Math.abs(hash) % nodeColors.length;
    };

    return (
        <div ref={containerRef} className="w-full h-full relative overflow-hidden" style={{ minHeight: '400px' }}>
            {/* Pure black gradient background for Cognitive OS */}
            <div className="absolute inset-0 bg-black/90 pointer-events-none" />
            <div className="absolute inset-0 bg-[radial-gradient(circle_at_center,_var(--tw-gradient-stops))] from-white/[0.01] via-transparent to-transparent opacity-50 pointer-events-none" />

            {/* Performance indicator now alerts gracefully when reaching very high amounts */}
            {rawData.nodes.length > 5000 && (
                <div className="absolute top-4 left-4 glass-card px-3 py-2 text-xs text-yellow-400 z-10 rounded-full border border-yellow-500/30 bg-black/40 backdrop-blur-md">
                    ⚡ Exibindo top {processedGraphData.nodes.length} de {rawData.nodes.length} nós para preservar performance.
                </div>
            )}

            <ForceGraph2D
                ref={fgRef}
                width={dimensions.width}
                height={dimensions.height}
                graphData={processedGraphData}
                backgroundColor="transparent"
                nodeLabel="name"
                nodeColor={(node: any) => nodeColors[getColorIndex(node.id)]}
                linkColor={(link: any) => highlightLinks.has(link) ? '#8B5CF6' : '#4B5563'} // Roxo vs Cinza escuro
                linkWidth={(link: any) => highlightLinks.has(link) ? 3 : 1}
                // linkOpacity={0.4} - Removido pois causa erro de TS
                nodeRelSize={8}
                nodeCanvasObject={(node: any, ctx, globalScale) => {
                    const label = node.name;
                    const fontSize = 12 / globalScale;
                    ctx.font = `${fontSize}px Inter, Sans-Serif`;

                    const index = getColorIndex(String(node.id));
                    const nodeColor = nodeColors[index];

                    // Highlight effect & Positive Decay
                    const isHighlighted = highlightNodes.has(node.id);
                    const isAnyHighlighted = highlightNodes.size > 0;
                    
                    // Se algum nó estiver focado e este não estiver, ele decai (Positive Decay na UI)
                    const baseOpacity = isAnyHighlighted ? (isHighlighted ? 1 : 0.1) : 0.6;
                    const nodeSize = isHighlighted ? 12 : 6;

                    // Draw glow effect
                    if (isHighlighted) {
                        ctx.shadowBlur = 30;
                        ctx.shadowColor = nodeColor;
                    } else {
                        ctx.shadowBlur = 5;
                        ctx.shadowColor = 'rgba(0,0,0,0.8)';
                    }

                    // Modifier nodeColor with opacity
                    const colorParts = nodeColor.match(/^#?([a-f\d]{2})([a-f\d]{2})([a-f\d]{2})$/i);
                    let fillStyle = nodeColor;
                    if (colorParts) {
                        const r = parseInt(colorParts[1], 16);
                        const g = parseInt(colorParts[2], 16);
                        const b = parseInt(colorParts[3], 16);
                        fillStyle = `rgba(${r}, ${g}, ${b}, ${baseOpacity})`;
                    }

                    // Draw node circle
                    ctx.beginPath();
                    ctx.arc(node.x, node.y, nodeSize, 0, 2 * Math.PI, false);
                    ctx.fillStyle = fillStyle;
                    ctx.fill();

                    // Draw border
                    ctx.strokeStyle = isHighlighted ? '#FFFFFF' : `rgba(255, 255, 255, ${baseOpacity * 0.3})`;
                    ctx.lineWidth = isHighlighted ? 2 / globalScale : 1 / globalScale;
                    ctx.stroke();

                    // Reset shadow
                    ctx.shadowBlur = 0;

                    // Draw label (only if zoomed in or highlighted or few nodes)
                    const showLabel = (globalScale > 2.5 && !isAnyHighlighted) || isHighlighted || (processedGraphData.nodes.length < 30 && !isAnyHighlighted);
                    
                    if (showLabel) {
                        ctx.textAlign = 'center';
                        ctx.textBaseline = 'middle';
                        ctx.font = `${isHighlighted ? 'bold ' : ''}${fontSize}px Inter, system-ui`;

                        // Background for text readability
                        const textWidth = ctx.measureText(label).width;
                        const bkgHeight = fontSize * 1.2;

                        // Semi-transparent background
                        ctx.fillStyle = isHighlighted ? 'rgba(0,0,0,0.8)' : 'rgba(0,0,0,0.4)';
                        ctx.fillRect(node.x - textWidth / 2 - 4, node.y + nodeSize + 4, textWidth + 8, bkgHeight);

                        // Text color
                        ctx.fillStyle = isHighlighted ? '#FFFFFF' : `rgba(255, 255, 255, ${baseOpacity})`;
                        ctx.fillText(label, node.x, node.y + nodeSize + 4 + (bkgHeight / 2));
                    }
                }}
                // Physics Configuration
                d3VelocityDecay={0.3} // More friction = less jitter
                d3AlphaDecay={0.02} // Slower cooling = better layout
                warmupTicks={200}
                cooldownTicks={100}
                onEngineStop={() => console.log('🎨 Grafo estabilizado')}

                // Interaction
                enableNodeDrag={true}
                enableZoomInteraction={true}
                enablePanInteraction={true}
                onNodeHover={handleNodeHover}
                onBackgroundClick={() => {
                    setHighlightNodes(new Set());
                    setHighlightLinks(new Set());
                }}
            />
        </div>
    );
};
