import React, { useState, useEffect, useRef } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Brain, Sparkles } from 'lucide-react';
import { useUI } from '../contexts/UIContext';
import { auth, db } from '../firebase';
import { collection, addDoc } from 'firebase/firestore';
import { localKGExtractorService } from '../services/kgExtractorService';
import toast from 'react-hot-toast';

export const CognitiveInput: React.FC = () => {
  const [text, setText] = useState('');
  const [isFocused, setIsFocused] = useState(false);
  const [showSerendipity, setShowSerendipity] = useState(false);
  const [isSaving, setIsSaving] = useState(false);
  const textareaRef = useRef<HTMLTextAreaElement>(null);

  const { isCommandPaletteOpen } = useUI();

  // Heurística de digitação
  useEffect(() => {
    const wordCount = text.trim().split(/\s+/).filter(w => w.length > 0).length;
    if (wordCount > 3) setShowSerendipity(true);
    else setShowSerendipity(false);

    // Auto-resize
    if (textareaRef.current) {
        textareaRef.current.style.height = 'auto';
        textareaRef.current.style.height = `${textareaRef.current.scrollHeight}px`;
    }
  }, [text]);

  const handleSave = async () => {
    if (!text.trim() || !auth.currentUser) return;
    setIsSaving(true);
    try {
      const extraction = await localKGExtractorService.extract(text.trim());
      const nodes = extraction.entities.map((e, idx) => ({ id: `${Date.now()}-${idx}`, name: e.name, val: e.val }));
      const links = extraction.relations;

      await addDoc(collection(db, "sessions"), {
        text: text.trim(),
        timestamp: Date.now(),
        updatedAt: Date.now(),
        uid: auth.currentUser.uid,
        nodes: nodes.length > 0 ? nodes : null,
        links: links.length > 0 ? links : null,
        processingMethod: 'local-ner'
      });
      
      setText('');
      setShowSerendipity(false);
      setIsFocused(false);
      textareaRef.current?.blur();
      toast.success('Pensamento cristalizado.', {
          icon: '✨',
          style: {
            background: 'rgba(0,0,0,0.8)',
            color: '#fff',
            border: '1px solid rgba(255,255,255,0.1)'
          }
      });
    } catch (e) {
      toast.error('Erro ao formar memória.');
    } finally {
      setIsSaving(false);
    }
  };

  const handleKeyDown = (e: React.KeyboardEvent) => {
    if (e.ctrlKey && e.key === 'Enter') handleSave();
    if (e.key === 'Escape') {
        setIsFocused(false);
        textareaRef.current?.blur();
    }
  };

  const isFlowModeActive = isFocused || text.length > 0;

  return (
    <>
      {/* Background Dimmer when active */}
      <AnimatePresence>
        {isFlowModeActive && (
            <motion.div 
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                exit={{ opacity: 0 }}
                transition={{ duration: 1.5, ease: 'easeOut' }}
                className="fixed inset-0 bg-black/60 backdrop-blur-sm pointer-events-none z-10"
            />
        )}
      </AnimatePresence>

      <div className={`fixed inset-0 z-20 flex flex-col items-center justify-center pointer-events-none transition-all duration-700 ${isFlowModeActive ? '-mt-10' : 'mt-0'}`}>
        
        {/* Central Input Core */}
        <div className="relative w-full max-w-4xl px-8 pointer-events-auto flex flex-col items-center">
            <textarea
                ref={textareaRef}
                value={text}
                onChange={(e) => setText(e.target.value)}
                onFocus={() => setIsFocused(true)}
                onBlur={() => !text && setIsFocused(false)}
                onKeyDown={handleKeyDown}
                disabled={isCommandPaletteOpen || isSaving}
                placeholder="O que estás a pensar agora?"
                className={`w-full bg-transparent border-none font-serif text-center transition-all duration-700 ease-out text-gray-200 placeholder-white/20 resize-none focus:ring-0 custom-scrollbar-hidden ${isFlowModeActive ? 'text-3xl md:text-5xl leading-[1.4] opacity-100' : 'text-xl md:text-3xl opacity-60 hover:opacity-90'}`}
                rows={1}
            />

            {/* Hint Fade */}
            <AnimatePresence>
                {isFlowModeActive && (
                    <motion.div 
                        initial={{ opacity: 0, y: 10 }}
                        animate={{ opacity: 0.5, y: 0 }}
                        exit={{ opacity: 0, y: 10 }}
                        className="mt-8 text-xs font-mono uppercase tracking-[0.3em] flex gap-4 text-white/50"
                    >
                        <span>Ctrl+Enter para cristalizar</span>
                        <span>Esc para esquecer</span>
                    </motion.div>
                )}
            </AnimatePresence>

            {/* Serendipity Live Insights (Floating Shards) */}
            <AnimatePresence>
                {showSerendipity && (
                    <motion.div 
                        initial={{ opacity: 0, scale: 0.95, y: 20 }}
                        animate={{ opacity: 1, scale: 1, y: 0 }}
                        exit={{ opacity: 0, scale: 0.9, y: 10 }}
                        transition={{ duration: 0.6, ease: 'easeOut' }}
                        className="absolute top-full mt-16 flex flex-wrap justify-center gap-4 w-full max-w-3xl"
                    >
                        {/* Mock Insight Shards that look alive */}
                        <div className="glass-card bg-white/5 border-white/10 px-6 py-4 rounded-2xl flex items-start gap-4 hover:bg-white/10 transition-all cursor-pointer shadow-[0_0_30px_rgba(255,255,255,0.02)]">
                            <Sparkles className="w-4 h-4 text-white/40 mt-1 shrink-0" />
                            <div className="flex flex-col text-left">
                                <span className="text-white/80 text-sm font-medium mb-1">Padrão Detetado: Isolamento</span>
                                <span className="text-white/40 text-xs line-clamp-2">Tal como mencionaste na semana passada sobre a equipa de engineering.</span>
                            </div>
                        </div>

                        <div className="glass-card bg-indigo-500/5 border-indigo-500/20 px-6 py-4 rounded-2xl flex items-start gap-4 hover:bg-indigo-500/10 transition-all cursor-pointer shadow-[0_0_30px_rgba(99,102,241,0.03)]">
                            <Brain className="w-4 h-4 text-indigo-400 mt-1 shrink-0" />
                            <div className="flex flex-col text-left">
                                <span className="text-indigo-200 text-sm font-medium mb-1">Conexão Neuronal</span>
                                <span className="text-indigo-400/50 text-xs line-clamp-2">Ligar este pensamento a "Manifesto 2024".</span>
                            </div>
                        </div>
                    </motion.div>
                )}
            </AnimatePresence>
        </div>
      </div>
    </>
  );
};
