import { useMemo } from 'react';
import type { SessionData } from './useSessions';

export interface GraphNode {
    id: string;
    name: string;
    val: number;
}

export interface GraphLink {
    source: string;
    target: string;
}

export interface GraphData {
    nodes: GraphNode[];
    links: GraphLink[];
}

export const useGraphData = (sessions: SessionData[]) => {
    return useMemo(() => {
        const allNodes: GraphNode[] = [];
        const allLinks: GraphLink[] = [];

        // Set para evitar duplicatas de IDs de nós
        const nodeIds = new Set<string>();

        sessions.forEach((session) => {
            // 1. Nó principal da memória
            const memoryNodeId = session.id;
            if (!nodeIds.has(memoryNodeId)) {
                allNodes.push({
                    id: memoryNodeId,
                    name: session.text?.substring(0, 30) || 'Memória',
                    val: 5
                });
                nodeIds.add(memoryNodeId);
            }

            // 2. Nós do Knowledge Graph (se existirem)
            if (session.nodes && Array.isArray(session.nodes)) {
                session.nodes.forEach((node: any) => {
                    // Validação Rigorosa
                    if (!node) return;
                    if (typeof node === 'string') return; // Ignora nós antigos que eram strings
                    if (typeof node !== 'object') return;
                    if (!node.id) return;

                    const nodeId = String(node.id);

                    if (!nodeIds.has(nodeId)) {
                        allNodes.push({
                            id: nodeId,
                            name: String(node.name || node.id),
                            val: Number(node.val || 3)
                        });
                        nodeIds.add(nodeId);
                    }
                });
            }

            // 3. Links do Knowledge Graph
            if (session.links && Array.isArray(session.links)) {
                session.links.forEach((link: any) => {
                    if (!link) return;
                    if (typeof link !== 'object') return;
                    if (!link.source || !link.target) return;

                    // Só adiciona links se ambos os nós existirem (para evitar erros do d3)
                    // Mas como adicionamos nós dinamicamente, vamos confiar na validação do componente ou adicionar todos
                    // O componente MemoryGraph já tem proteção extra, então enviamos dados limpos aqui.
                    allLinks.push({
                        source: String(link.source),
                        target: String(link.target)
                    });
                });
            }
        });

        return { nodes: allNodes, links: allLinks };
    }, [sessions]);
};
