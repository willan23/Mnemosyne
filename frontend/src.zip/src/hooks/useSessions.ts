import { useState, useEffect, useMemo } from 'react';
import { collection, query, where, orderBy, onSnapshot } from 'firebase/firestore';
import { db } from '../firebase';
import type { User } from 'firebase/auth';

export interface FilterOptions {
    dateRange: string;
    tags: string[];
    category?: string;
}

// Definindo tipos para evitar 'any'
export interface SessionData {
    id: string;
    text: string;
    timestamp: number;
    updatedAt: number;
    uid: string;
    tags?: string[];
    category?: string;
    lastViewedAt?: number;
    nodes?: Array<{ id: string; label: string; type: string }>;
    links?: Array<{ source: string; target: string }>;
}

export const useSessions = (user: User | null, searchQuery: string, filters: FilterOptions) => {
    const [sessions, setSessions] = useState<SessionData[]>([]);
    const [isLoading, setIsLoading] = useState(true);
    const [orphanedCount, setOrphanedCount] = useState(0);

    // Firestore Listener
    useEffect(() => {
        if (!user) {
            setSessions([]);
            setIsLoading(false);
            return;
        }

        const q = query(
            collection(db, "sessions"),
            where("uid", "==", user.uid),
            orderBy("timestamp", "desc")
        );

        const unsubscribe = onSnapshot(q, (snapshot) => {
            const allSessions: SessionData[] = [];

            snapshot.forEach((doc) => {
                const data = doc.data();
                // Garantir tipagem básica ao ler do Firestore
                allSessions.push({
                    id: doc.id,
                    text: data.text || '',
                    timestamp: data.timestamp || 0,
                    updatedAt: data.updatedAt || data.timestamp || 0,
                    uid: data.uid,
                    tags: data.tags,
                    category: data.category,
                    lastViewedAt: data.lastViewedAt,
                    nodes: data.nodes,
                    links: data.links
                } as SessionData);
            });

            setSessions(allSessions);
            setIsLoading(false);

            // Verificar órfãos (lógica movida do App.tsx, mas simplificada aqui)
            // A verificação de chave mnemônica deve ser feita no componente visual se necessário
            setOrphanedCount(allSessions.length);
        });

        return () => unsubscribe();
    }, [user]);

    // Lógica de Filtro e Busca
    const filteredSessions = useMemo(() => {
        let result = [...sessions];

        // Filtro de Texto
        if (searchQuery.trim()) {
            const queryText = searchQuery.toLowerCase();
            result = result.filter(s =>
                s.text?.toLowerCase().includes(queryText) ||
                s.tags?.some((tag: string) => tag.toLowerCase().includes(queryText))
            );
        }

        // Filtro de Data
        if (filters.dateRange !== 'all') {
            const now = Date.now();
            const ranges: Record<string, number> = {
                today: 24 * 60 * 60 * 1000,
                week: 7 * 24 * 60 * 60 * 1000,
                month: 30 * 24 * 60 * 60 * 1000,
                year: 365 * 24 * 60 * 60 * 1000
            };
            const cutoff = now - (ranges[filters.dateRange] || 0);
            result = result.filter(s => s.timestamp > cutoff);
        }

        // Filtro de Tags
        if (filters.tags.length > 0) {
            result = result.filter(s =>
                s.tags?.some((tag: string) => filters.tags.includes(tag))
            );
        }

        // Filtro de Categoria
        if (filters.category) {
            result = result.filter(s => s.category === filters.category);
        }

        return result;
    }, [sessions, searchQuery, filters]);

    // Extrair Tags e Categorias disponíveis para a UI
    const availableResources = useMemo(() => {
        const tags = new Set<string>();
        const categories = new Set<string>();

        sessions.forEach(s => {
            s.tags?.forEach(tag => tags.add(tag));
            if (s.category) categories.add(s.category);
        });

        return {
            tags: Array.from(tags).sort(),
            categories: Array.from(categories).sort()
        };
    }, [sessions]);

    return {
        sessions,
        filteredSessions,
        isLoading,
        orphanedCount,
        availableTags: availableResources.tags,
        availableCategories: availableResources.categories
    };
};
