import { useState, useEffect } from 'react';
import { collection, query, where, getDocs } from 'firebase/firestore';
import { db, auth } from '../firebase';
import { getPlanLimits, hasReachedLimit, type PlanLimits } from '../config/planLimits';

export interface UsageStats {
    memories: {
        thisMonth: number;
        limit: number;
        canCreate: boolean;
    };
    attachments: {
        images: {
            thisMonth: number;
            limit: number;
            canUpload: boolean;
        };
        audio: {
            thisMonth: number;
            limit: number;
            canUpload: boolean;
        };
        pdfs: {
            thisMonth: number;
            limit: number;
            canUpload: boolean;
        };
    };
    storage: {
        usedGB: number;
        limitGB: number;
        canUpload: boolean;
    };
}

export const useSubscriptionLimits = (userPlan: string = 'free') => {
    const [limits, setLimits] = useState<PlanLimits>(getPlanLimits(userPlan));
    const [usage, setUsage] = useState<UsageStats | null>(null);
    const [isLoading, setIsLoading] = useState(true);

    useEffect(() => {
        setLimits(getPlanLimits(userPlan));
    }, [userPlan]);

    useEffect(() => {
        const loadUsage = async () => {
            if (!auth.currentUser) {
                setIsLoading(false);
                return;
            }

            try {
                // Calcular início do mês atual
                const now = new Date();
                const startOfMonth = new Date(now.getFullYear(), now.getMonth(), 1).getTime();

                // Query para memórias deste mês
                const sessionsRef = collection(db, 'sessions');
                const q = query(
                    sessionsRef,
                    where('uid', '==', auth.currentUser.uid),
                    where('timestamp', '>=', startOfMonth)
                );
                const snapshot = await getDocs(q);

                // Contar anexos
                let imagesCount = 0;
                let audioCount = 0;
                let pdfsCount = 0;

                snapshot.docs.forEach(doc => {
                    const data = doc.data();
                    if (data.attachments) {
                        imagesCount += (data.attachments.images || []).length;
                        audioCount += (data.attachments.audio || []).length;
                        pdfsCount += (data.attachments.pdfs || []).length;
                    }
                });

                const memoriesThisMonth = snapshot.size;

                // Calcular uso de storage (simplificado - em produção, usar Storage API)
                const storageUsedGB = 0; // TODO: Implementar cálculo real

                setUsage({
                    memories: {
                        thisMonth: memoriesThisMonth,
                        limit: limits.memories.monthly,
                        canCreate: !hasReachedLimit(memoriesThisMonth, limits.memories.monthly),
                    },
                    attachments: {
                        images: {
                            thisMonth: imagesCount,
                            limit: limits.attachments.images.monthlyLimit,
                            canUpload: limits.attachments.images.enabled &&
                                !hasReachedLimit(imagesCount, limits.attachments.images.monthlyLimit),
                        },
                        audio: {
                            thisMonth: audioCount,
                            limit: limits.attachments.audio.monthlyLimit,
                            canUpload: limits.attachments.audio.enabled &&
                                !hasReachedLimit(audioCount, limits.attachments.audio.monthlyLimit),
                        },
                        pdfs: {
                            thisMonth: pdfsCount,
                            limit: limits.attachments.pdfs.monthlyLimit,
                            canUpload: limits.attachments.pdfs.enabled &&
                                !hasReachedLimit(pdfsCount, limits.attachments.pdfs.monthlyLimit),
                        },
                    },
                    storage: {
                        usedGB: storageUsedGB,
                        limitGB: limits.storage.maxGB,
                        canUpload: storageUsedGB < limits.storage.maxGB,
                    },
                });
            } catch (error) {
                console.error('Error loading usage stats:', error);
            } finally {
                setIsLoading(false);
            }
        };

        loadUsage();
    }, [auth.currentUser, limits]);

    return {
        limits,
        usage,
        isLoading,
    };
};
