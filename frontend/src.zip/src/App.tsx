import React, { useState, useEffect } from 'react';
import { Routes, Route, useNavigate } from 'react-router-dom';
import { KeyCeremony } from './components/KeyCeremony';
import { MemoryGraph } from './components/MemoryGraph';
import { SettingsModal } from './components/SettingsModal';
import { MemoryEditorModal } from './components/MemoryEditorModal';
import { OrphanedMemoriesWarning } from './components/OrphanedMemoriesWarning';
import { ShareView } from './pages/ShareView';
import { PricingPage } from './pages/PricingPage';
import { CheckoutSuccess } from './pages/CheckoutSuccess';
import { CheckoutCancel } from './pages/CheckoutCancel';
import { PrivacyPage } from './pages/PrivacyPage';
import { UniversePage } from './pages/UniversePage';
import { LandingPage } from './pages/LandingPage';
import { LoginPage } from './pages/LoginPage';
import type { FilterOptions, SessionData } from './hooks/useSessions';
import { Search, Compass, Activity, Brain, Globe } from 'lucide-react';
import { db, auth } from './firebase';
import { onAuthStateChanged } from 'firebase/auth';
import { Toaster } from 'react-hot-toast';

import { useSessions } from './hooks/useSessions';
import { useGraphData } from './hooks/useGraphData';
import { useUI } from './contexts/UIContext';
import { CommandPalette } from './components/CommandPalette';
import { CognitiveInput } from './components/CognitiveInput';

const App: React.FC = () => {
  const navigate = useNavigate();
  const [isAuthenticated, setIsAuthenticated] = useState<boolean>(false);
  const [mnemonic, setMnemonic] = useState<string[] | null>(null);

  // States para UI Data
  const [editingSession, setEditingSession] = useState<SessionData | null>(null);

  // OS Navigation (Tabs/Modes)
  const [activeMode, setActiveMode] = useState<'flow' | 'insights'>('flow');

  const [searchQuery] = useState('');
  const [filters] = useState<FilterOptions>({
    dateRange: 'all',
    tags: [],
    category: undefined
  });

  const [showOrphanedWarning, setShowOrphanedWarning] = useState(false);

  // States do Global Store (UI Context)
  const {
    isSettingsOpen, setIsSettingsOpen,
    openCommandPalette
  } = useUI();

  // Custom Hooks substituindo lógica pesada
  // O hook useSessions agora gerencia todo o estado de dados e filtros
  const {
    sessions,
    orphanedCount
  } = useSessions(auth.currentUser, searchQuery, filters);

  // Hook específico para transformar sessões em dados de grafo
  const graphData = useGraphData(sessions);

  // Auth state listener
  useEffect(() => {
    const unsubscribe = onAuthStateChanged(auth, (user) => {
      setIsAuthenticated(!!user);
    });
    return () => unsubscribe();
  }, []);

  // Load mnemonic from localStorage
  useEffect(() => {
    const saved = localStorage.getItem('mnemosyne_mnemonic');
    if (saved) {
      setMnemonic(JSON.parse(saved));
    }
  }, []);

  // Monitorar warning de orfãos vindo do hook
  useEffect(() => {
    if (orphanedCount > 0 && !mnemonic) {
      setShowOrphanedWarning(true);
    } else {
      setShowOrphanedWarning(false);
    }
  }, [orphanedCount, mnemonic]);

  const handleKeyComplete = (newMnemonic: string[]) => {
    localStorage.setItem('mnemosyne_mnemonic', JSON.stringify(newMnemonic));
    setMnemonic(newMnemonic);
  };

  const handleCleanOrphanedMemories = async () => {
    if (!confirm('⚠️ ATENÇÃO: Isso eliminará TODAS as suas memórias antigas. Continuar?')) return;

    try {
      if (!auth.currentUser) return;

      const { collection, query, where, getDocs, deleteDoc } = await import('firebase/firestore');
      const sessionsRef = collection(db, 'sessions');
      const q = query(sessionsRef, where('uid', '==', auth.currentUser.uid));
      const snapshot = await getDocs(q);

      await Promise.all(snapshot.docs.map(doc => deleteDoc(doc.ref)));

      alert(`✅ ${snapshot.docs.length} memórias eliminadas.`);
      setShowOrphanedWarning(false);
    } catch (error) {
      const err = error as { message?: string };
      console.error('Error cleaning orphaned memories:', error);
      alert(`Erro: ${err.message || 'Erro desconhecido'}`);
    }
  };

  return (
    <>
      <Toaster position="top-right" />
      <Routes>
        <Route path="/share/:shareId" element={<ShareView />} />
        <Route path="/pricing"        element={<PricingPage />} />
        <Route path="/checkout/success" element={<CheckoutSuccess />} />
        <Route path="/checkout/cancel"  element={<CheckoutCancel />} />
        <Route path="/privacy"        element={<PrivacyPage />} />
        <Route path="/universe"       element={<UniversePage />} />
        <Route path="/login"          element={<LoginPage />} />

        <Route path="/" element={
          !isAuthenticated ? (
            <LandingPage />
          ) : (
            <div className="min-h-screen bg-[#0a0a0a] text-[#ededed]">
              <div className="fixed inset-0 pointer-events-none">
                <div className="absolute top-[10%] left-[20%] w-[40vw] h-[40vw] bg-indigo-600/5 rounded-full blur-[120px]" />
                <div className="absolute bottom-[20%] right-[10%] w-[30vw] h-[30vw] bg-purple-600/5 rounded-full blur-[100px]" />
              </div>

              {!mnemonic ? (
                <KeyCeremony onComplete={handleKeyComplete} />
              ) : (
                <div className="relative z-10 w-full h-screen flex flex-col overflow-hidden bg-black">
                  <header className="absolute top-0 left-0 w-full p-8 flex justify-between items-start z-40 pointer-events-none mix-blend-difference">
                    <div className="flex items-center gap-3 pointer-events-none opacity-40">
                      <Brain className="w-5 h-5 text-white" />
                    </div>
                  </header>

                  {showOrphanedWarning && (
                    <div className="absolute top-24 left-1/2 -translate-x-1/2 z-50">
                      <OrphanedMemoriesWarning
                        memoriesCount={orphanedCount}
                        onResetAndClean={handleCleanOrphanedMemories}
                        onDismiss={() => setShowOrphanedWarning(false)}
                      />
                    </div>
                  )}

                  <main className="flex-1 w-full h-full relative">
                    <div className={`absolute inset-0 transition-opacity duration-[2000ms] ${activeMode === 'insights' ? 'opacity-100 z-30' : 'opacity-40 z-0'}`}>
                      <MemoryGraph data={graphData} />
                    </div>

                    {activeMode === 'flow' && <CognitiveInput />}

                    <div className="absolute bottom-10 left-1/2 -translate-x-1/2 flex items-center gap-2 z-50 p-2 rounded-full border border-white/5 bg-black/80 backdrop-blur-3xl shadow-2xl mix-blend-screen overflow-hidden">
                      <button
                        onClick={() => setActiveMode('flow')}
                        className={`flex items-center gap-2 px-6 py-3 rounded-full transition-all duration-300 ${activeMode === 'flow' ? 'bg-white/10 text-white shadow-[inset_0_0_20px_rgba(255,255,255,0.05)]' : 'text-white/40 hover:text-white/80'}`}
                      >
                        <Compass className="w-4 h-4" />
                        <span className="text-[10px] uppercase tracking-widest font-medium">Flow</span>
                      </button>

                      <button
                        onClick={() => setActiveMode('insights')}
                        className={`flex items-center gap-2 px-6 py-3 rounded-full transition-all duration-300 ${activeMode === 'insights' ? 'bg-white/10 text-white shadow-[inset_0_0_20px_rgba(255,255,255,0.05)]' : 'text-white/40 hover:text-white/80'}`}
                      >
                        <Activity className="w-4 h-4" />
                        <span className="text-[10px] uppercase tracking-widest font-medium">Insights</span>
                      </button>

                      <button
                        onClick={() => { setActiveMode('flow'); openCommandPalette(); }}
                        className="flex items-center gap-2 px-6 py-3 rounded-full text-white/40 hover:text-white/80 hover:bg-white/5 transition-all duration-300 border-l border-white/5 ml-2"
                      >
                        <Search className="w-4 h-4" />
                        <span className="text-[10px] uppercase tracking-widest font-medium">Search</span>
                      </button>

                      <button
                        onClick={() => navigate('/universe')}
                        className="flex items-center gap-2 px-6 py-3 rounded-full text-white/40 hover:text-white/80 hover:bg-white/5 transition-all duration-300 border-l border-white/5 ml-2"
                      >
                        <Globe className="w-4 h-4" />
                        <span className="text-[10px] uppercase tracking-widest font-medium">Universe</span>
                      </button>
                    </div>
                  </main>

                  <CommandPalette />
                  <SettingsModal isOpen={isSettingsOpen} onClose={() => setIsSettingsOpen(false)} mnemonic={mnemonic} onResetKey={() => { localStorage.removeItem('mnemosyne_mnemonic'); setMnemonic(null); }} />
                  <MemoryEditorModal session={editingSession} allMemories={sessions} onMemoryClick={setEditingSession} onClose={() => setEditingSession(null)} />
                </div>
              )}
            </div>
          )
        } />
      </Routes>
    </>
  );
};

export default App;

